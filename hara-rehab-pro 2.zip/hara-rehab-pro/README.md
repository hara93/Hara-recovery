# HARA Rehab Pro

PWA aplikacija za osobni rehab i trening plan: SI zglob, piriformis, unutarnja rotacija kuka, povratak sprintu i nogometu.

## Sadržaj
- Dashboard
- Quick rehab i full rehab
- Snaga A/B/C
- Povratak nogometu po fazama
- Testovi i praćenje boli / Whoop recovery
- Offline PWA support

## Instalacija na mobitel
Objavi folder na Netlify/Vercel, otvori link u Safari/Chrome i odaberi Add to Home Screen.

const $ = s => document.querySelector(s);
const state = JSON.parse(localStorage.getItem('haraRehabPro')||'{}');
state.day ??= 1; state.phase ??= 1; state.done ??= {}; state.logs ??= []; state.tests ??= [];
const save=()=>localStorage.setItem('haraRehabPro',JSON.stringify(state));

const rehabFull = [
 ['A1','Thoracic Rotation','2×8/strana','Rotacija između lopatica, kukovi mirni. Ne forsirati lumbalno.'],
 ['A2','90/90 Hip IR aktiva','2×8–10/strana','Desni kuk prioritet. Bez štipanja u preponi.'],
 ['A3','Wall Ankle Mobility L','2×12–15','Lijevi gležanj, peta na podu, koljeno prema 2. prstu.'],
 ['B1','Lateral Band Walk','2×12 koraka/strana','Zamjena za previše clamshella. Koljeno ne pada unutra.'],
 ['B2','Single-leg Bridge lagani','2×10/strana','Bez agresivne unutarnje rotacije. Samo ako nema SI iritacije.'],
 ['C1','Step-down kontrola','2×8/strana','Desna kao nosiva noga. Ogledalo, koljeno prema 2. prstu.'],
 ['C2','Dead Bug','2×8/strana','Anti-rotacija zdjelice, rebra dolje, križa mirna.'],
 ['D1','Diafragmatično disanje','5 ciklusa','Reset živčanog sustava, 4-0-6 ili 4-4-6.']
];
const quick = [rehabFull[0], rehabFull[1], rehabFull[2], rehabFull[4], rehabFull[6], rehabFull[7]];
const strength = {
 A:[['Hip Thrust bilateral','4×8','RPE 13–15/20 prva 2–4 tjedna. Ne hiperekstenzija.'],['RDL kontrolirani','3×8–10','Kreni konzervativno. Ako SI reagira dan poslije, smanji 10–20%.'],['RFESS / Bulgarian Split Squat','3×8/strana','Zdjelica ravna, koljeno prema 2. prstu.'],['Pallof Press','3×12/strana','Anti-rotacija za SI.'],['Copenhagen short lever','3×15–25 s','Aduktori za šut i stabilnost.']],
 B:[['Single-leg RDL kontrateralni grip','3×8/strana','Desna noga oslonac, bučica u lijevoj ruci.'],['Side Plank Hip Abduction','3×8–10','Bolja funkcija od stalnog clamshella.'],['Sliding Leg Curl','3×8–10','Nordic tek kad nema reakcije 24 h.'],['Adductor Squeeze / Copenhagen iso','3×15 s + 10','Kontrola prepona i šuta.'],['Plank Shoulder Tap','3×8/strana','Zdjelica mirna.']],
 C:[['Goblet Squat do boxa','4×8','Kontrolirano, bez kolapsa koljena.'],['Step-up s bučicama','3×8–10/strana','Bez odraza donjom nogom.'],['Suitcase Carry','4×25–40 m/strana','Zamjena za drugi hip thrust u tjednu; SI stabilnost bez nabijanja kuka.'],['TRX Row / Inverted Row','3×10–12','Gornji dio i postura.'],['Assisted Hip Airplane','2×5/strana','Rotacijska kontrola za sprint/šut.']]
};
const phases = [
 ['Hodanje','30 min normalnog hodanja, rehab, lagani skip A','0–1/10 bol, normalna mehanika'],
 ['Lagano trčanje','2×10–15 min na 50–60%, skip A/B','0–2/10 bol i bez reakcije idući dan'],
 ['Ubrzanja','60–70–80%, lateralni pomaci','Step-down 10× čist, simetričan korak'],
 ['Promjena smjera','T-test, zaustavljanja, sprint 80–90%','Bez boli i bez kompenzacije'],
 ['Šut + 1v1','Šut lagano → jače, dribling','Bez povećanja SI/piriformis boli'],
 ['Utakmica','Ekipni trening, 30–60 min, zatim puna','Sve prethodno 0–1/10']
];

function doneKey(id){return new Date().toISOString().slice(0,10)+'_'+id}
function toggle(id){state.done[doneKey(id)] = !state.done[doneKey(id)]; save(); render()}
function pct(){const keys=[...quick.map(x=>x[0])]; return Math.round(keys.filter(k=>state.done[doneKey(k)]).length/keys.length*100)}
function rec(){const last=state.logs.at(-1); if(!last) return 'Upiši bol i Whoop. Danas kreni s Quick rehabom.'; if(last.pain>=4) return 'Crveno: preskoči snagu i sprint. Samo lagani rehab + šetnja.'; if(last.pain>=3||last.rec<45) return 'Žuto: smanji volumen 30–50%, bez Nordica, sprinta i rezova.'; return 'Zeleno: možeš planirani trening, ali ostani u pravilima boli 0–2/10.'}

function exList(arr){return `<div class="card">${arr.map(e=>`<div class="exercise" onclick="this.classList.toggle('open')"><div class="row"><div><b>${e[1]}</b><div class="mini">${e[2]}</div></div><button class="check ${state.done[doneKey(e[0])]?'done':''}" onclick="event.stopPropagation();toggle('${e[0]}')">✓</button></div><div class="details">${e[3]}</div></div>`).join('')}</div>`}

function dashboard(){return `<section class="grid"><div class="card hero"><div class="row"><div><p class="eyebrow">Današnja preporuka</p><h2>${rec()}</h2></div><div class="score">${pct()}%</div></div><div class="ring"><i style="width:${pct()}%"></i></div></div><div class="card"><h3>Brzi unos</h3><div class="inputrow"><div class="field"><label>Bol 0–10</label><input id="pain" type="number" min="0" max="10" value="${state.logs.at(-1)?.pain??1}"></div><div class="field"><label>Whoop recovery %</label><input id="rec" type="number" min="0" max="100" value="${state.logs.at(-1)?.rec??70}"></div></div><br><button class="btn" onclick="addLog()">Spremi stanje</button></div><div class="card"><h3>Quick rehab danas</h3></div>${exList(quick)}<div class="traffic"><div class="green">0–2<br>Nastavi</div><div class="yellow">3<br>Smanji</div><div class="red">4+<br>Stani</div></div></section>`}
function rehab(){return `<section class="grid"><div class="card hero"><h2>Rehab protokol — poboljšana verzija</h2><p class="muted">Puni protokol 4–5× tjedno. Quick verziju možeš svaki dan. IR vježbe ne forsirati: štipanje u preponi = smanji raspon.</p></div><div class="seg"><button class="active">Full 15–20 min</button><button>Quick 8–10 min</button></div>${exList(rehabFull)}<div class="card"><h3>Rotacija IR vježbi</h3><p class="quote">Dan 1: 90/90 IR + side-lying IR. Dan 2: prone IR + bridge s laganom IR. Ne sve maksimalno svaki dan.</p></div></section>`}
function strengthView(){return `<section class="grid"><div class="card hero"><h2>Snaga 3× tjedno</h2><p class="muted">Manje duplanja hip thrust/bridge obrazaca. Trening C ima Suitcase Carry umjesto unilateral hip thrusta.</p></div>${['A','B','C'].map(k=>`<div class="card"><h2>Trening ${k}</h2>${strength[k].map((e,i)=>`<div class="exercise"><div><b>${e[0]}</b><div class="mini">${e[1]}</div><div class="details" style="display:block">${e[2]}</div></div><div class="inputrow"><div class="field"><label>kg</label><input placeholder="kg"></div><div class="field"><label>RPE /20</label><input placeholder="14"></div></div></div>`).join('')}</div>`).join('')}</section>`}
function football(){return `<section class="grid"><div class="card hero"><h2>Povratak sprintu i nogometu</h2><p class="muted">Napreduješ po kriterijima, ne po kalendaru. Ako bol poraste idući dan, vrati se fazu nazad 2–3 dana.</p></div>${phases.map((p,i)=>`<div class="card phase ${i+1<state.phase?'done':''} ${i+1==state.phase?'current':''}"><div class="row"><h3>${i+1}. ${p[0]}</h3><button class="ghost" onclick="state.phase=${i+1};save();render()">Odaberi</button></div><ul class="list"><li>${p[1]}</li><li><b>Kriterij:</b> ${p[2]}</li></ul></div>`).join('')}</section>`}
function tests(){return `<section class="grid"><div class="card hero"><h2>Testovi svakih 7–14 dana</h2><p class="muted">Mjeri uvijek isto. Bol pri testu = stani.</p></div><div class="card"><div class="inputrow"><div class="field"><label>Hip IR desno °</label><input id="t_ir"></div><div class="field"><label>Wall ankle L cm</label><input id="t_ankle"></div><div class="field"><label>Side plank D sek</label><input id="t_spd"></div><div class="field"><label>Side plank L sek</label><input id="t_spl"></div><div class="field"><label>Step-down 1–5</label><input id="t_step"></div><div class="field"><label>Bol šut 0–10</label><input id="t_pain"></div></div><br><button class="btn" onclick="addTest()">Spremi test</button></div><div class="card"><h3>Zadnji testovi</h3>${state.tests.slice(-5).reverse().map(t=>`<p class="mini">${t.date}: IR ${t.ir}°, gležanj ${t.ankle} cm, step ${t.step}/5, bol šut ${t.pain}/10</p>`).join('')||'<p class="muted">Još nema unosa.</p>'}</div></section>`}
function addLog(){state.logs.push({date:new Date().toISOString(),pain:+$('#pain').value,rec:+$('#rec').value});save();render()}
function addTest(){state.tests.push({date:new Date().toISOString().slice(0,10),ir:$('#t_ir').value,ankle:$('#t_ankle').value,spd:$('#t_spd').value,spl:$('#t_spl').value,step:$('#t_step').value,pain:$('#t_pain').value});save();render()}
let tab='dashboard';
function render(){ $('#view').innerHTML = ({dashboard,rehab,strength:strengthView,football,tests})[tab](); document.querySelectorAll('.tabbar button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab)); }
document.querySelectorAll('.tabbar button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;render()});
let deferred; window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferred=e;$('#installBtn').classList.remove('hidden')}); $('#installBtn').onclick=()=>deferred?.prompt();
if('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js');
render();
